import Combine
import PlaygroundSupport
import UIKit

PlaygroundPage.current.needsIndefiniteExecution = true

/// COMBINE: Swift'te asenkron ve olay temelli programlama için kullanılan bir framework'tir.

/*
 - Publisher
 - Subsciber
 - Operator (tryMap, Map, CompactMap etc.)

 - Back pressure: Publisher'dan gelen değerin neye dönüşeceğine karar verme.
 */

/*
 JUST
 FUTURE
 PASSTHROUGHSUBJECT
 */

// Just: "Just" operatörü, sadece bir değeri içeren bir yayın oluşturur. Yani, bu operatör kullanıldığında, sadece belirtilen bir değeri yayınlayan bir yayın oluşturulur.Daha sonra yayın hayatına son verir.
/*
 let subscriber = Just("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.")

 subscriber
     .sink { value in
         print(value)
     }

 subscriber
     .map { $0.count }
     .sink { value in
         print(value)
     }

 /// Receive completion ile hata olması durumunda görebiliriz.
 subscriber
     .map { $0.count }
     .sink(receiveCompletion: { result in
         switch result {
         case .finished:
             print("Finished")
         case .failure(let error):
             print(error.localizedDescription)
         }
     }) { value in
         print(value)
     }

 - .debounce = .debounce(for: .milliseconds(500), scheduler: DispatchQueue.main)
 - .throttle =.throttle(for: .milliseconds(500), scheduler: DispatchQueue.main, latest: true)

 .debounce operatörü, yayınlanan değerler arasında belirli bir gecikme süresi ekler. Ancak, gelen her yeni değer yayınlandıktan sonra beklenen süre boyunca yeni bir değer yayınlanmaz. Beklenen süre boyunca yeni bir değer yayınlanmadığında, bu süre boyunca yayınlanan son değer alınır ve abonelere iletilir.

 Öte yandan, .throttle operatörü, belirli bir süre boyunca gelen tüm değerleri engeller. Belirli bir süre boyunca değerlerin yayınlanmasını engeller ve belirlenen süre boyunca sadece bir değeri alır. .throttle operatöründe, engelleme süresi boyunca gelen tüm değerlerin beklenmeden atılması farklıdır. .throttle operatörü, yayınlanan değerler arasındaki süreyi kontrol etmek için kullanılır, ancak .debounce operatörü yalnızca gelen değerler arasındaki süreyi kontrol eder ve belirli bir gecikme süresi ekler.

 Dolayısıyla, .debounce operatörü, gelen değerler arasında belirli bir gecikme eklerken, .throttle operatörü belirli bir süre boyunca gelen tüm değerleri engeller.

 - .eraseToAnyPublisher() ile type erasure yapabiliriz.
 */

// Future: Swift programlama dilinde, "Future", gelecekte tamamlanacak bir işlemi temsil etmek için kullanılan bir türdür. Asenkron programlamada sıklıkla kullanılır ve genellikle Combine framework'ü ile birlikte kullanılır.Future, bir işlemin sonucunu temsil eden bir değerdir. Ancak bu değer henüz mevcut değildir, çünkü ilgili işlem henüz tamamlanmamıştır. Bu nedenle, Future, işlem tamamlandığında bir değer veya bir hata döndüreceği vaadinde bulunur.Bir Future örneği oluşturduğunuzda, bu işlem hemen başlatılmaz. Ancak bu işlemi başlatmak için bir "Executor" kullanabilirsiniz.
/*
 let futureResult = Future<Int, Never> { promise in // Never hata olmayacağını garanti eder.
     Task {
         try await Task.sleep(nanoseconds: NSEC_PER_SEC * 3)
         promise(.success(Int.random(in: 0 ... 3)))
     }
 }

 let cancellabe = futureResult
     .sink { value in
         print(value)
     }
 */

// PassthroughSubject: Bir PassthroughSubject, yayınladığı değerleri direkt olarak abonelere ileten bir yayıncıdır. Yani, bir değer yayınladığınızda, aboneler hemen bu değeri alır. Bu, yayınların doğrudan iletilmesi anlamına gelir, dolayısıyla arada herhangi bir işleme veya geçikmeye gerek kalmaz.
/*
 let subject = PassthroughSubject<Int, Never>()
 subject.send(0) // Value subscribe olmadan gönderildiği için bu değer alınmaz.
 let cancellable = subject
     .sink { result in
         switch result {
         case .finished:
             print("Finished")
         case .failure(let error):
             print(error.localizedDescription)
         }
     } receiveValue: { value in
         print(value)
     }

 subject.send(1)
 subject.send(2)
 subject.send(3)
 subject.send(completion: .finished)
 */

// NOTLAR:
/*
 //.assign(to: \.textIsValid, on: self)
 assign işlevi, Combine çerçevesinde yayıncıları ve yayıncılardan gelen değerleri bir nesnenin belirli bir anahtar yoluyla birleştirmek için kullanılır. Yukarıdaki kodda, $textFieldText bir yayıncıdır. Bu yayıncı, textFieldText özelliğindeki değişiklikleri izler.

 map operatörü, yayıncıdan gelen değerleri dönüştürür. Bu durumda, textFieldText özelliğindeki metni alır ve uzunluğunun 3'ten büyük olup olmadığını kontrol eder. Daha sonra, bu koşula göre bir Bool değer üretir.

 Sonrasında assign operatörü, bu dönüştürülmüş değeri belirtilen anahtar yoluyla birleştirir. assign operatörü, yayıncıdan gelen değeri, belirtilen nesnenin belirtilen anahtar yoluyla atar. Yani $textFieldText yayıncısından gelen değer, textIsValid özelliğine atanır.

 Böylece, her textFieldText özelliği değiştiğinde, uzunluğunun 3'ten büyük olup olmadığına bağlı olarak textIsValid özelliği de güncellenir. Bu, genellikle kullanıcı girişinin geçerliliğini kontrol etmek için yaygın bir yaklaşımdır.

 .debounce(for: .seconds(0.5), scheduler: DispatchQueue.main) ifadesi, metin alanındaki herhangi bir değişiklikten sonra minimum 0.5 saniye beklenmesini sağlar. Bu, kullanıcının metni yazarken arka arkaya hızlı değişiklikler yapması durumunda, son yazılan değeri almadan önce biraz beklenmesini sağlar. Örneğin, kullanıcı hızlı bir şekilde yazarken, her karakter girdisinden sonra doğrudan işlem yapmak yerine, kullanıcının bir an için durması ve gerçekten ne yazmak istediğini tamamlaması beklenir. Bu, performansı artırır ve gereksiz işlem maliyetini azaltır.

 .combineLatest fonksiyonu, bir veya daha fazla yayıncıdan gelen değerlerin en son değerlerini kullanarak yeni bir değer oluşturur. Bu fonksiyon, herhangi bir yayıncıdan yeni bir değer geldiğinde, diğer tüm yayıncılardan en son değerlerini alır ve bu değerlerle birlikte bir sonuç üretir.
 */

// Array publisher
/*
 let values = [1, 3, 5, 5, 7, 7, 7, 9]

 let publisher = values
     .publisher
     .sink { value in
         print("Publisher: \(value)")
     }

 let publisher2 = values
     .publisher
     .removeDuplicates() // array içinde aynı olanları siler
     .sink { value in
         print("Publisher2: \(value)")
     }

 let publisher3 = values
     .publisher
     .removeDuplicates()
     .dropFirst() // İlk gelen yayını siler
     .sink { value in
         print("Publisher3: \(value)")
     }

 let publisher4 = values
     .publisher
     .max()
     .sink { value in
         print("Publisher4: \(value)")
     }
 */

// URLSession.dataTaskPublisher
/*
 struct Post: Identifiable, Codable {
     let id: Int
     let userId: Int
     let title: String
     let body: String
 }

 let subscription = URLSession.shared
     .dataTaskPublisher(for: URL(string: "https://jsonplaceholder.typicode.com/posts")!)
     .tryMap { data, response in
         guard let response = response as? HTTPURLResponse,
               response.statusCode >= 200, response.statusCode <= 299
         else {
             throw URLError(.badURL)
         }

         return data
     }
     .decode(type: [Post].self, decoder: JSONDecoder())
     .sink { result in
         switch result {
         case .failure(let error):
             dump(error)
         case .finished:
             print("Finished")
         }
     } receiveValue: { returnedPosts in
         dump(returnedPosts)
     }

 var cancellables = Set<AnyCancellable>()
 let result: AnyPublisher = URLSession.shared
     .dataTaskPublisher(for: URL(string: "https://jsonplaceholder.typicode.com/posts")!)
     .map { $0.data }
     .decode(type: [Post].self, decoder: JSONDecoder()) // Gelen datayı bir nesneye decode eder.
     .receive(on: DispatchQueue.main) // UI güncellemesi için main thread'a geçer.
     .eraseToAnyPublisher() // type erasure

 result
     .sink { result in
         switch result {
         case .failure(let error):
             dump(error)
         case .finished:
             print("Finished")
         }
     } receiveValue: { returnedPosts in
         dump(returnedPosts)
     }
     .store(in: &cancellables)

 // cancellable?.cancel() :cancel edilmesini sağlıyor.
 // cancellable?.store(in: &) :bu cancellable değerini bir yerde depolamayı sağlıyor.
 */

// ImageDownloader Custom Publisher oluşturma.

/*
 struct ImageDownloaderPublisher: Publisher {
     typealias Output = URL
     typealias Failure = Never

     let urls: [URL]

     func receive<S>(subscriber: S) where S: Subscriber, Never == S.Failure, URL == S.Input {
         let subscription = ImageDownloaderSubscription(urls: urls, subscriber: subscriber)

         subscriber.receive(subscription: subscription)
     }
 }

 final class ImageDownloaderSubscription<S: Subscriber>: Subscription where S.Input == URL, S.Failure == Never {
     var urls: [URL]
     var subscriber: S?

     init(urls: [URL], subscriber: S) {
         self.urls = urls
         self.subscriber = subscriber

         Task {
             await startDownloading()
         }
     }

     private func startDownloading() async {
         await withTaskGroup(of: URL?.self) { group in
             for url in urls {
                 group.addTask {
                     let response = try? await URLSession.shared.data(from: url)

                     if let data = response?.0 {
                         let docDir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first

                         if let filePath = docDir?.appendingPathComponent(url.lastPathComponent) {
                             try? data.write(to: filePath)
                             return filePath
                         }
                     }
                     return nil
                 }
             }

             for await localFileURL in group {
                 subscriber?.receive(localFileURL!)
             }

             subscriber?.receive(completion: .finished)
         }
     }

     func request(_ demand: Subscribers.Demand) {}

     func cancel() {
         subscriber = nil
     }
 }

 let publisher = ImageDownloaderPublisher(urls: [
     URL(string: "https://picsum.photos/100")!,
     URL(string: "https://picsum.photos/101")!,
 ])

 let cancellable = publisher.sink { _ in
     print("completed")
 } receiveValue: { value in
     print(value)
 }

 */

import PlaygroundSupport
import UIKit

PlaygroundPage.current.needsIndefiniteExecution = true

// MARK: - JSON Serialization, JSON: JavaScript Object Notation

// [String:Any]
let jsonExample = """
{
    "name":"Yunus",
    "surname":"Berdibek",
    "age":22
}
""".data(using: .utf8)!

do {
    let resultExample = try JSONSerialization.jsonObject(with: jsonExample, options: .mutableContainers) as! [String: Any]

    if let name = resultExample["name"] as? String,
       let surname = resultExample["surname"] as? String,
       let age = resultExample["age"] as? Int
    {
        print(name + surname + age.description)
    }
}

// MARK: Decodable

struct Person: Decodable, Encodable {
    let name: String
    let surname: String
    let age: Int
}

do {
    let result = try JSONDecoder().decode(Person.self, from: jsonExample)

    dump(result)
} catch {
    dump(error)
}

// MARK: - Encodable

do {
    let person = Person(name: "Yunus", surname: "XXXX", age: 22)
    let encodedPerson = try JSONEncoder().encode(person)

    dump(encodedPerson.count) // byte
} catch {}

// MARK: - DecodingKeyStrategy

let socialMediaJSON = """
{
    "user_name":"yunusberdibekk",
    "user_following":325,
    "user_followers":5464
}
""".data(using: .utf8)!

struct SocialMediaModel: Codable {
    let userName: String
    let userFollowing: Int
    let userFollowers: Int
}

do {
    let decoder = JSONDecoder()
    decoder.keyDecodingStrategy = .convertFromSnakeCase

    let socialMedia = try decoder.decode(SocialMediaModel.self, from: socialMediaJSON)
    dump(socialMedia)
} catch {
    dump(error)
}

///

let socialMediaJSON2 = """
{
    "user_NAME":"yunusberdibekk",
    "user_FOLLOWING":325,
    "user_FOLLOWERS":5464
}
""".data(using: .utf8)!

struct SocialMediaModel2: Decodable {
    let username: String
    let userFollowing: Int
    let userFollowers: Int

    enum CodingKeys: String, CodingKey {
        case username = "user_NAME"
        case userFollowing = "user_FOLLOWING"
        case userFollowers = "user_FOLLOWERS"
    }

    init(from decoder: any Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.username = try container.decode(String.self, forKey: .username)
        self.userFollowing = try container.decode(Int.self, forKey: .userFollowing)
        self.userFollowers = try container.decode(Int.self, forKey: .userFollowers)
    }
}

do {
    let socialMedia = try JSONDecoder().decode(SocialMediaModel2.self, from: socialMediaJSON2)
    dump(socialMedia)
} catch {
    dump(error)
}

///

let socialMediaArrayJson = """
[
    {
        "date_of_birth":"27.01.1996",
        "user_name":"Ali",
        "user_surname":"Veli"
    },
    {
        "date_of_birth":"05.11.1989",
        "user_name":"john",
        "user_surname":"Ken"
    },
    {
        "date_of_birth":"27.01.1996",
        "user_name":"Fernando",
        "user_surname":"Muslera"
    }
]
""".data(using: .utf8)!

struct SocialPerson: Decodable {
    let userName: String
    let userSurname: String
    let birthdate: String

    private enum CodingKeys: String, CodingKey {
        case userName = "user_name"
        case userSurname = "user_surname"
        case birthdate = "date_of_birth"
    }

    init(from decoder: any Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.userName = try container.decode(String.self, forKey: .userName)
        self.userSurname = try container.decode(String.self, forKey: .userSurname)
        self.birthdate = try container.decode(String.self, forKey: .birthdate)
    }
}

do {
    let object = try JSONDecoder().decode([SocialPerson].self, from: socialMediaArrayJson)
    let usernameList = object.map { $0.userName }

    dump(object)
    dump(usernameList)
} catch {
    dump(error)
}

///

let socialMediaJson2 = """
{
    "date":"27.01.1996",
    "name":"Fernando",
    "surname":"Muslera"
}
""".data(using: .utf8)!

struct SocialPerson2: Decodable {
    let name: String
    let surname: String
    let date: Date
}

do {
    /// https://www.nsdateformatter.com
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "dd.MM.yy"

    let decoder = JSONDecoder()
    decoder.dateDecodingStrategy = .formatted(dateFormatter)

    let object = try decoder.decode(SocialPerson2.self, from: socialMediaJson2)
    dump(object)
} catch {
    dump(error)
}

/// Nested JSON Object

let nestedJSONObject1 = """
{
    "person": {
        "name":"John Doe",
        "age":30,
        "adress": {
            "street":"123 Main St",
            "city":"Anytown",
            "zipcode":1234
        },
        "email":"john@example.co",
    }
}
""".data(using: .utf8)!

struct NestedJSONObject1: Codable {
    let person: NestedPerson1
}

struct NestedPerson1: Codable {
    let name: String
    let age: Int
    let adress: NestedAdress1
    let email: String
}

struct NestedAdress1: Codable {
    let street: String
    let city: String
    let zipcode: Int
}

do {
    let object = try JSONDecoder().decode(NestedJSONObject1.self, from: nestedJSONObject1)

    print("NestedJSONObject1")
    dump(object)
} catch {
    dump(error)
}

/// Arbitrary(Keyfi) Types

// Burada bir datanın türünün farklı gelmesi durumunda ele alınacak yöntem yazmaktadır.
let arbitraryJSONData = """
{
    "name":"Fernando",
    "zero":false
}
""".data(using: .utf8)!

struct ArbitraryPerson: Decodable {
    let name: String
    let zero: CustomDecodeType
}

struct CustomDecodeType: Decodable {
    let value: Any

    enum CodingKeys: CodingKey {
        case value
    }

    // Buradaki işlem ile value değerinin türünü bu init içinde belirliyebiliriz.
    init(from decoder: any Decoder) throws {
        let container = try decoder.singleValueContainer()

        if let stringType = try? container.decode(String.self) {
            self.value = stringType
        } else if let booleanType = try? container.decode(Bool.self) {
            self.value = booleanType
        } else if let integerType = try? container.decode(Int.self) {
            self.value = integerType
        } else {
            self.value = try container.decode(Double.self)
        }
    }
}

do {
    let object = try JSONDecoder().decode(ArbitraryPerson.self, from: arbitraryJSONData)

    print("ArbitraryPerson")
    dump(object)
} catch {
    dump(error)
}

/// Decoding Inherited Type

let inheritedJSON1 = """
[
   {
        "name":"Ford",
        "price":"1.2",
        "electric":false,
        "kw":0,
        "batteryId":""
    },
   {
        "name":"Tesla",
        "price":"1.6",
        "electric":true,
        "kw":234,
        "batteryId":"33UEDJH"
    },
   {
        "name":"Mercedes",
        "price":"2",
        "electric":true,
        "kw":0,
        "batteryId":""
    }
]
""".data(using: .utf8)!

class Car: Decodable {
    let name: String
    let price: String

    init(name: String, price: String) {
        self.name = name
        self.price = price
    }
}

class ElectricCar: Car {
    let electric: Bool
    let kw: Int
    let batteryId: String

    private enum CodingKeys: CodingKey {
        case electric
        case kw
        case batteryId
    }

    required init(from decoder: any Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.electric = try container.decode(Bool.self, forKey: .electric)
        self.kw = try container.decode(Int.self, forKey: .kw)
        self.batteryId = try container.decode(String.self, forKey: .batteryId)
        try super.init(from: decoder)
    }
}

do {
    let object = try JSONDecoder().decode([ElectricCar].self, from: inheritedJSON1)
    let eCarList = object.filter { $0.electric }.map { $0.name }

    print("inheritedJSON1")
    dump(object)

    print("ECarList")
    dump(eCarList)
} catch {
    dump(error)
}

// FlatModel

let flatJSON = """
{
    "name":"Yunus",
    "surname":"Berdibek",
    "age":22,
    "adress": {
        "city":"Elazig",
        "country":"Turkey"
    }
}
""".data(using: .utf8)!

struct PersonFlatModel: Decodable {
    let name: String
    let surname: String
    let age: Int

    let city: String
    let country: String

    private enum CodingKeys: CodingKey {
        case name
        case surname
        case age
        case adress
    }

    private enum NestedCodingKeys: CodingKey {
        case city
        case country
    }

    init(from decoder: any Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.name = try container.decode(String.self, forKey: .name)
        self.surname = try container.decode(String.self, forKey: .surname)
        self.age = try container.decode(Int.self, forKey: .age)

        let adressContainer = try container.nestedContainer(keyedBy: NestedCodingKeys.self, forKey: .adress)
        self.city = try adressContainer.decode(String.self, forKey: .city)
        self.country = try adressContainer.decode(String.self, forKey: .country)
    }
}

do {
    let object = try JSONDecoder().decode(PersonFlatModel.self, from: flatJSON)

    print("FlatJSON")
    dump(object)
} catch {
    dump(error)
}

/// Decoding different type value

// 150.44 = kmh(virgül solu), 81.22122 = knot
let jsonType = """
{
    "speed": ["150.44,81.221222"]
}
""".data(using: .utf8)!

struct DifferentModel: Decodable {
    let speed: [ConvertSpeed]
}

struct ConvertSpeed: Decodable {
    let kmh: Double
    let knot: Double

    init(from decoder: any Decoder) throws {
        let container = try decoder.singleValueContainer()
        let string = try container.decode(String.self)
        let values = string.components(separatedBy: ",") // belirtilen karaktere göre stringi bölerek array oluşturur.

        guard values.count == 2,
              let kmh = Double(values[0]),
              let knot = Double(values[1])
        else {
            throw DecodingError.dataCorrupted(DecodingError.Context(codingPath: container.codingPath, debugDescription: "Invalid coordinates"))
        }

        self.kmh = kmh
        self.knot = knot
    }
}

do {
    let result = try JSONDecoder().decode(DifferentModel.self, from: jsonType)

    print("Different type")
    dump(result.speed[0])
} catch {
    dump(error)
}
